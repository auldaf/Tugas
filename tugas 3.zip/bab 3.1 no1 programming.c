/*
 * Compute the sum and average of two numbers.
 */
#include <stdio.h> /* printf, scanf definitions */
int
main(void)
{
 double one, two, /* input - numbers to process */
 sum, /* output - sum of one and two */
 average; /* output - average of one and two */
 /* Get two numbers. */
 printf("Input angka pertama: ");
 scanf ("%lf", &one);
 
 printf("Input angka kedua: ");
 scanf("%lf", &two);
 
 /* Compute sum of numbers. */
 
 /* Compute average of numbers. */
 
 /* Display sum and average. */
 printf("Jumlah kedua angka tersebut= %.2lf\n",one+two);
 printf("Rata-rata kedua bilangan tersebut= %.2lf",(one+two)/2);
 
 return (0);
}
