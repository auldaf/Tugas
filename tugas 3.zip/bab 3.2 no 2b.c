/*
*menghitung angka yang sudha diberikan
*/
#include <stdio.h> /* definitions of printf, scanf */
#include <math.h> /* definition of sqrt */

int main()
{
	double a;				/*input angka*/
	a=ceil(16.2);			/*masukkan rumus*/
	printf("Hasilnya adalah: %lf", a);	/*printout hasil*/
}
