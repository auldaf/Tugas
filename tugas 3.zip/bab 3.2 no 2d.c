/*
*program menghitung angka dan rumus yang sudah ditentukan
*/
#include <stdio.h> /* definitions of printf, scanf */
#include <math.h> /* definition of floor */

int main()
{
	double a;				/*input angka a*/
	a=floor(21.8 + 0.8);	/*input rumus yang akan digunakan*/
	printf("Hasilnya adalah= %lf",&a);	/*output hasil dari rumus dan ngka yang sudah ditentukan*/
}
