/*
*menghitung hasil dari angka yg sudah ditentukan
*/
#include <stdio.h> /* definitions of printf, scanf */
#include <math.h> /* definition */

int main()
{
	double a;
	a=log10(10000.0);
	printf("Hasilnya adalah: %lf",a);
}
